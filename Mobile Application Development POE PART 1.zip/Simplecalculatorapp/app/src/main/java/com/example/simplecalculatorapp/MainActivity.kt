package com.example.simplecalculatorapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var num1= findViewById<EditText>(R.id.number1)
        var num2= findViewById<EditText>(R.id.number2)
        var button1= findViewById<Button>(R.id.addit)
        var clearbutton= findViewById<Button>(R.id.clearbutton)
        var multiplybutton= findViewById<Button>(R.id.multiply)
        var divide= findViewById<Button>(R.id.divide)
        var minus= findViewById<Button>(R.id.minus)

        button1.setOnClickListener {
            var addnum1 = num1.text.toString().toInt()
            var addnum2 = num2.text.toString().toInt()
            var result = addnum1 + addnum2
            Toast.makeText(this, "Answer: $addnum1 + $addnum2 = $result", Toast.LENGTH_SHORT).show()
        }

        multiplybutton.setOnClickListener {
            var addnum1 = num1.text.toString().toInt()
            var addnum2 = num2.text.toString().toInt()
            var result = addnum1 * addnum2
            Toast.makeText(this, "Answer: $addnum1 * $addnum2 = $result", Toast.LENGTH_SHORT).show()
        }

            divide.setOnClickListener {
                var addnum1 = num1.text.toString().toInt()
                var addnum2 = num2.text.toString().toInt()
                var result = addnum1 / addnum2
                Toast.makeText(this, "Answer: $addnum1 / $addnum2 = $result", Toast.LENGTH_SHORT).show()

            }
                minus.setOnClickListener{
                    var addnum1= num1.text.toString().toInt()
                    var addnum2=num2.text.toString().toInt()
                    var result=addnum1 - addnum2
                    Toast.makeText(this,"Answer: $addnum1 - $addnum2 = $result",Toast.LENGTH_SHORT).show()
        }

        clearbutton.setOnClickListener {
            num1.setText("");
            num2.setText("");

            Toast.makeText(this,"Cleared",Toast.LENGTH_SHORT).show()
        }




    }
   


    }



